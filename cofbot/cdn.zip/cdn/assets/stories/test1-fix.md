# Start
![TitleImage](../asylum/shots/title.jpg)
​​
# Escape the Asylum!
An interactive fiction thriller developed for Slack
Copyright (c) 2020
​​
# Home

You accept an invitation to playtest a new physical escape room. The setting of the game is a mental asylum called "Bell Hill".

What do you want to do?

  - [Surf Facebook](#surf-facebook)
  - [Corridor](#corridor)


## Surf Facebook
![facebook](../asylum/shots/fb-ad.jpg)

You continue surfing facebook some more...


## Corridor
![corridor](../asylum/rooms/green-hall.jpg)


you enter the corridor

> ask about clothes

“Is this part of the game?!” you stammer angrily
​“It’s all in the terms and conditions,” says the first orderly

----




  - [Go Home](#home)
  - [Start](#start)

