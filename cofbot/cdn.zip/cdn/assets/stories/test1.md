![escape_the_asylum_text](/Users/john.knauss/Desktop/IF Slack Project/Illustrations/escape_the_asylum_text.png)
​
​
**Escape the Asylum!**
An interactive fiction thriller developed for Slack
Copyright (c) 2020
​
​
**At Home**
You accept an invitation to playtest a new physical escape room. The setting of the game is a mental asylum called "Bell Hill".




**ask about clothes**
​
<p>“Is this part of the game?!” you stammer angrily.</p?
​
<p>“It’s all in the terms and conditions,” says the first
orderly. </p>
